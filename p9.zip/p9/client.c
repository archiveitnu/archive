#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080
#define BUFFER_SIZE 1024

int main()
{
    int sock;
    struct sockaddr_in server_addr;

    char filename[100];
    char buffer[BUFFER_SIZE];

    sock = socket(AF_INET, SOCK_STREAM, 0);

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    connect(sock,
            (struct sockaddr *)&server_addr,
            sizeof(server_addr));

    printf("Enter filename: ");
    scanf("%s", filename);

    send(sock, filename, sizeof(filename), 0);

    FILE *fp = fopen("received_file.txt", "wb");

    while (1)
    {
        int bytes = recv(sock, buffer, BUFFER_SIZE, 0);

        if (bytes <= 0)
            break;

        fwrite(buffer, 1, bytes, fp);
    }

    fclose(fp);

    printf("File received successfully\n");

    close(sock);

    return 0;
}