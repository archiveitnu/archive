#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <pthread.h>

#define PORT 8080
#define BUFFER_SIZE 1024

void *handle_client(void *socket_desc)
{
    int client_sock = *(int *)socket_desc;
    char filename[100];
    char buffer[BUFFER_SIZE];

    recv(client_sock, filename, sizeof(filename), 0);

    printf("Client requested file: %s\n", filename);

    FILE *fp = fopen(filename, "rb");

    if (fp == NULL)
    {
        strcpy(buffer, "File not found");
        send(client_sock, buffer, strlen(buffer), 0);
    }
    else
    {
        while (fgets(buffer, BUFFER_SIZE, fp) != NULL)
        {
            send(client_sock, buffer, strlen(buffer), 0);
        }

        fclose(fp);
    }

    printf("File transfer completed\n");

    close(client_sock);
    free(socket_desc);

    return NULL;
}

int main()
{
    int server_sock, client_sock;
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_len;

    pthread_t thread_id;

    server_sock = socket(AF_INET, SOCK_STREAM, 0);

    if (server_sock < 0)
    {
        printf("Socket creation failed\n");
        exit(1);
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    bind(server_sock,
         (struct sockaddr *)&server_addr,
         sizeof(server_addr));

    listen(server_sock, 5);

    printf("Server waiting for clients...\n");

    while (1)
    {
        client_len = sizeof(client_addr);

        client_sock = accept(server_sock,
                             (struct sockaddr *)&client_addr,
                             &client_len);

        printf("Client connected\n");

        int *new_sock = malloc(sizeof(int));
        *new_sock = client_sock;

        pthread_create(&thread_id,
                       NULL,
                       handle_client,
                       (void *)new_sock);

        pthread_detach(thread_id);
    }

    close(server_sock);

    return 0;
}