#ifndef PROTOCOL_H
#define PROTOCOL_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define PORT 8080
#define MAX_DATA 100

typedef struct
{
    int seq;
    char data[MAX_DATA];
} Frame;

typedef struct
{
    int ack;
} Ack;

#endif