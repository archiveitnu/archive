#define MAX_SEQ 1 /* must be 1 for protocol 3 */

#include "protocol.h"
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <pthread.h>

#define PORT 8080
int sock,file_size,file_size1;
frame s;

/* Go to sleep for a period of seconds */
static void* g_start_timer(void *args)
{
    usleep(*((int *)(args)));
    while(1)
    {
      send(sock,&s,sizeof(frame),0);
      printf("Resent: %d\t%d\n",s.seq,file_size1-file_size);
      usleep(*((int *)(args)));
    }
    pthread_exit(NULL);
}

int socket_connection()
{
    int server_fd, new_socket;
    ssize_t valread;
    struct sockaddr_in address;
    int opt = 1;
    socklen_t addrlen = sizeof(address);

    // Creating socket file descriptor
    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("socket failed");
        exit(EXIT_FAILURE);
    }

    // Forcefully attaching socket to the port 8080
    if (setsockopt(server_fd, SOL_SOCKET,
                   SO_REUSEADDR | SO_REUSEPORT, &opt,
                   sizeof(opt))) {
        perror("setsockopt");
        exit(EXIT_FAILURE);
    }
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);

    // Forcefully attaching socket to the port 8080
    if (bind(server_fd, (struct sockaddr*)&address,
             sizeof(address))
        < 0) {
        perror("bind failed");
        exit(EXIT_FAILURE);
    }
    if (listen(server_fd, 3) < 0) {
        perror("listen");
        exit(EXIT_FAILURE);
    }
    if ((new_socket
         = accept(server_fd, (struct sockaddr*)&address,
                  &addrlen))
        < 0) {
        perror("accept");
        exit(EXIT_FAILURE);
    }

    return new_socket;

}

int from_network_layer(FILE *fp,char *buffer)
{
    if(file_size-MAX_PKT>=0)
    {
      fread(buffer,MAX_PKT,1,fp);
      file_size-=MAX_PKT;
      return MAX_PKT;
    }
    else if(file_size>0)
    {
      int temp=file_size;
      fread(buffer,file_size,1,fp);
      file_size=0;
      return temp;
    }
    else
    {
      return 0;
    }
}

void main()
{
    seq_nr next_frame_to_send; /* seq number of next outgoing frame */
    frame r;                   /* scratch variable */
    char buffer[MAX_PKT];             /* buffer for an outbound packet */
    pthread_t thread_id;
    next_frame_to_send = 0;      /* initialize outbound sequence numbers */
    FILE *fp=fopen("tmp.c","rb");
    fseek(fp,0L,SEEK_END);
    file_size=ftell(fp);
    file_size1=file_size;
    printf("%d\n",file_size);
    fseek(fp,0L,SEEK_SET);
    sock=socket_connection();
    int count=from_network_layer(fp,buffer); /* fetch first packet */
    if(count==0)
      exit(0);

    while(true)
    {
        strcpy(s.info,buffer);            /* construct a frame for transmission */
        s.seq = next_frame_to_send; /* insert sequence number in frame */
        s.size=count;
        send(sock,&s,sizeof(frame),0);      /* send it on its way */
        printf("Sent: %d\t%d\n",s.seq,file_size1-file_size);
        int u_seconds = 100000;
        int rc;
        rc =  pthread_create(&thread_id, NULL, g_start_timer, (void *) &u_seconds);
        if(rc)
          printf("=== Failed to create thread\n");
        recv(sock,&r,sizeof(frame),0);
        float random = (float) rand()/RAND_MAX;
        if(random<0.5)
        {
           printf("Ack lost\n");
           pthread_cancel(thread_id);
           pthread_join(thread_id,NULL);
        }
        else if (r.ack == next_frame_to_send)
        {
                printf("Received ack:%d\n",r.ack);
                pthread_cancel(thread_id);
                pthread_join(thread_id,NULL);
           //     getchar();
                count=from_network_layer(fp,buffer); /* get the next one to send */
                if(count==0)
                  break;
                inc(next_frame_to_send);     /* invert next frame to send */
        }
        else
        {
                printf("Duplicate Ack\n");
                pthread_cancel(thread_id);
                pthread_join(thread_id,NULL);
        }
    }
    pthread_join(thread_id, NULL);
    getchar();
    fclose(fp);
    close(sock);
}
